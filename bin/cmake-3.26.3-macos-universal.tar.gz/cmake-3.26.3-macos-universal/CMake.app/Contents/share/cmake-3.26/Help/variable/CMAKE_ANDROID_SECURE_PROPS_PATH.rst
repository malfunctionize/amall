CMAKE_ANDROID_SECURE_PROPS_PATH
-------------------------------

.. versionadded:: 3.4

Default value for the :prop_tgt:`ANDROID_SECURE_PROPS_PATH` target property.
See that target property for additional information.
