CMAKE_CTEST_ARGUMENTS
---------------------

.. versionadded:: 3.17

Set this to a :ref:`semicolon-separated list <CMake Language Lists>` of
command-line arguments to pass to :manual:`ctest(1)` when running tests
through the ``test`` (or ``RUN_TESTS``) target of the generated build system.
