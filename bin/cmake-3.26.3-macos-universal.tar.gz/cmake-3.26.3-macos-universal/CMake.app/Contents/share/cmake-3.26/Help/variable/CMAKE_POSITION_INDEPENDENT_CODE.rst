CMAKE_POSITION_INDEPENDENT_CODE
-------------------------------

Default value for :prop_tgt:`POSITION_INDEPENDENT_CODE` of targets.

This variable is used to initialize the
:prop_tgt:`POSITION_INDEPENDENT_CODE` property on all the targets.
See that target property for additional information.  If set, its
value is also used by the :command:`try_compile` command.
