CMAKE_Fortran_MODDIR_FLAG
-------------------------

Fortran flag for module output directory.

This stores the flag needed to pass the value of the
:prop_tgt:`Fortran_MODULE_DIRECTORY` target property to the compiler.
