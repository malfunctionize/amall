APPLE
-----

Set to ``True`` when the target system is an Apple platform
(macOS, iOS, tvOS or watchOS).
