CMAKE_COMPILE_WARNING_AS_ERROR
------------------------------

.. versionadded:: 3.24

Specify whether to treat warnings on compile as errors.

This variable is used to initialize the
:prop_tgt:`COMPILE_WARNING_AS_ERROR` property on all the targets.
