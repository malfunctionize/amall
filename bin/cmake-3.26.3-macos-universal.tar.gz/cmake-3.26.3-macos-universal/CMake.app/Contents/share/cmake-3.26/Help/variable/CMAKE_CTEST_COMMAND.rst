CMAKE_CTEST_COMMAND
-------------------

Full path to :manual:`ctest(1)` command installed with CMake.

This is the full path to the CTest executable :manual:`ctest(1)`
that can be used for custom commands or tests to invoke
CTest commands.
