CMAKE_AUTOMOC
-------------

Whether to handle ``moc`` automatically for Qt targets.

This variable is used to initialize the :prop_tgt:`AUTOMOC` property on all the
targets.  See that target property for additional information.
